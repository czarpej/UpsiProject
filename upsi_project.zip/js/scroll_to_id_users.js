jQuery(function($)
{
	//zresetuj scrolla
	$.scrollTo(0);

	$(document).ready(function() { $.scrollTo($('#users'), 300); }); 
}
);