<?php

$address='localhost';
$db_login='root';
$db_password='';
$db_name='upsi';